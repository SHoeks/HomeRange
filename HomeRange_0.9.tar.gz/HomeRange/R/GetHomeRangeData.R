#' GetHomeRangeData
#'
#' @description Downloads the latest HomeRange dataset and loads it as a data.frame into R.
#' @return The HomeRange dataset
#' @export
#'
#' @examples
#' library(HomeRange)
#' HomeRangeData <- GetHomeRangeData()
GetHomeRangeData = function() {

  # url to get csv from
  url <- "https://anonymous.4open.science/r/HomeRange-D913/HomeRangeData_2022-08-24.zip"

  # os specific seperator
  switch(Sys.info()[['sysname']],Windows= {sep = '\\'}, Linux  = {sep = '/'}, Darwin = {sep = '/'})

  # download csv
  download.file(url,paste0(tempdir(),sep,'HomeRangeData.zip'),method = "libcurl")

  # unzip file
  unzip(zipfile=paste0(tempdir(),sep,'HomeRangeData.zip'),exdir=tempdir())

  # read and return
  return(read.csv(paste0(tempdir(),sep,'HomeRangeData_2022-08-24.csv'),sep=','))

}

#' MakeStatTable
#'
#' @description Creates a table for the HomeRange dataset using the gridExtra package.
#' @param HomeRangeData the HomeRange dataset (can be retrieved by running: GetHomeRangeData())
#' @export
#'
#' @examples
#' HomeRangeData <- GetHomeRangeData()
#' MakeStatTable(HomeRangeData)
MakeStatTable = function(HomeRangeData, return_table = FALSE) {


  HomeRangeData$HR_Level_simple = NA
  HomeRangeData$HR_Level_simple[grep("Population",HomeRangeData$HR_Level)] = "Population"
  HomeRangeData$HR_Level_simple[grep("Group",HomeRangeData$HR_Level)] = "Group"
  HomeRangeData$HR_Level_simple[grep("Individual",HomeRangeData$HR_Level)] = "Individual"

  tab1 = tab2 = data.frame(Individual.level=rep(NA,5),
                    Group.level=rep(NA,5),
                    Population.level=rep(NA,5),
                    Total=rep(NA,5))

  rownames(tab1) = c("Terrestrial","Aquatic","Semi-aquatic","Aerial","All")
  rownames(tab2) = c("Terrestrial","Aquatic","Semi-aquatic","Aerial","All")

  # n data entries
  tab1[1,"Total"] = table(HomeRangeData$Realm)["Terrestrial"]
  tab1[2,"Total"] = table(HomeRangeData$Realm)["Aquatic"]
  tab1[3,"Total"] = table(HomeRangeData$Realm)["Semi-aquatic"]
  tab1[4,"Total"] = table(HomeRangeData$Realm)["Aerial"]

  HomeRangeData$count = 1
  table1 = aggregate(count~Realm+HR_Level_simple,data=HomeRangeData,sum)
  table1 = reshape2::dcast(table1, Realm~HR_Level_simple, value.var = "count")
  table1 = table1[c(4,2,3,1),c("Realm","Individual","Group","Population")]

  tab1$Individual.level[1] = table1$Individual[table1$Realm=="Terrestrial"]
  tab1$Individual.level[2] = table1$Individual[table1$Realm=="Aquatic"]
  tab1$Individual.level[3] = table1$Individual[table1$Realm=="Semi-aquatic"]
  tab1$Individual.level[4] = table1$Individual[table1$Realm=="Aerial"]

  tab1$Group.level[1] = table1$Group[table1$Realm=="Terrestrial"]
  tab1$Group.level[2] = table1$Group[table1$Realm=="Aquatic"]
  tab1$Group.level[3] = table1$Group[table1$Realm=="Semi-aquatic"]
  tab1$Group.level[4] = table1$Group[table1$Realm=="Aerial"]

  tab1$Population.level[1] = table1$Population[table1$Realm=="Terrestrial"]
  tab1$Population.level[2] = table1$Population[table1$Realm=="Aquatic"]
  tab1$Population.level[3] = table1$Population[table1$Realm=="Semi-aquatic"]
  tab1$Population.level[4] = table1$Population[table1$Realm=="Aerial"]
  tab1[5,] = colSums(tab1[1:4,])

  grid::grid.newpage()
  gridExtra::grid.table(tab1)

  if(return_table) return(tab1)


}

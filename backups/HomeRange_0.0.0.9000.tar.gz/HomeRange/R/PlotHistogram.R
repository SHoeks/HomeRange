#' PlotHistogram
#'
#' @export
#'
#' @examples PlotHistogram(HomeRangeData)
PlotHistogram = function(HomeRangeData) {

  Realms = unique(HomeRangeData$Realm)
  Level = unique(HomeRangeData$HR_Level)
  HomeRangeData$HR_Level2 = "Population"
  HomeRangeData$HR_Level2[HomeRangeData$HR_Level=="Individual"] = "Individual"

  colors = c("#999999", "#E69F00", "#56B4E9","pink")
  colors = c("#999999","#288FB4","#61529F","#DE703C")

  # filter usign Isopleth_Size. > 75%
  iso = c("95", "100","80", "75", "77", "85","90", "86.5", "96",
          "99", "97.5", "Home range", "97", "94", "92", "70 - 100", "88", "79", "82",
          "76", "60 - 90", "65 - 90", "50-95", "75-95", "95-99", "85.7", ">95", "98")

  HomeRangeData2 = HomeRangeData[HomeRangeData$Isopleth_Size%in%iso,]

  ggplot2::ggplot(HomeRangeData2, ggplot2::aes(x=log10(Home_Range_km2), fill=Realm,color=Realm)) +
    ggplot2::geom_histogram(position="identity",alpha=0.9, bins = 30) +
    ggplot2::scale_color_manual(values=colors) +
    ggplot2::scale_fill_manual(values=colors) +
    ggplot2::facet_grid(ggplot2::vars(Realm), ggplot2::vars(HR_Level2), scales = "free_y") +
    ggplot2::xlab("Log10(home range km^2) ") +
    ggplot2::ylab("Number of home ranges") +
    ggplot2::theme_light() +
    ggplot2::theme(legend.position="none") +
    ggplot2::theme(strip.background = ggplot2::element_rect(fill="#D9D9D9")) +
    ggplot2::theme(strip.text = ggplot2::element_text(colour = 'black'))

}

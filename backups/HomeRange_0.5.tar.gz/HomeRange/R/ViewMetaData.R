#' ViewMetaData
#'
#' @description This function opens the metadata pdf file in the browser.
#' @export
#'
#' @examples
#' library(HomeRange)
#'
#' # view HomeRange metadata
#' ViewMetaData()
ViewMetaData = function() browseURL("http://510867850.swh.strato-hosting.eu/Metadata_2022_07_27.pdf")

#' MergeWithCOMBINE
#'
#' @return A combined data set, containing all the data of HomeRange merged with COMBINE
#' @export
#'
#' @examples MergedData <- MergeWithCOMBINE()
#'
MergeWithCOMBINE = function(HomeRangeData, COMBINE) {

  colnames(COMBINE) = paste0("COMBINE_",colnames(COMBINE))
  sp_idx = match(HomeRangeData$Species,COMBINE$COMBINE_iucn2020_binomial)
  COMBINE = COMBINE[sp_idx,]
  merged_data = cbind(HomeRangeData,COMBINE)

  return(merged_data)

}

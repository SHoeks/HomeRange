# load package
library('HomeRange')

# package info
?HomeRange

# test functions
data <- GetData()

# plotting data
PlotMap(data)
PlotHistogram(data)

# get more information
MakeStatTable(data)

# match with the COMBINE imputed dataset
COMBINE <- read.csv("/Users/osx/SHoeks/FlyingRunningSwimming/Literature Search/DataHarmonization_SH/trait_data_imputed.csv")
merged_data = MergeWithCOMBINE(data, COMBINE)

# example plot of the merged data
plot(merged_data$Body_mass_kg*1000,merged_data$COMBINE_adult_mass_g,
     log = "xy", pch=21, cex=0.7, bg="grey",
     xlab="body mass g HomeRange",ylab="body mass g COMBINE")
abline(0,1,col="red")
